<?php

return [
    'adminEmail' => 'admin@example.com',
    'loginWithEmail' => true,
];
