<?php

use app\modules\admin\assets\AppAsset;
use yii\helpers\Html;
use yii\helpers\Url;

//подключаем AppAsset
AppAsset::register($this);
?>
<!doctype html>
<html lang="en">
<head>
  <?= Html::csrfMetaTags() ?>
  <meta charset="<?= Yii::$app->charset ?>" />
  <link rel="icon" type="image/png" href="assets/img/favicon.ico">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

  <title><?= Html::encode($this->title) ?></title>
  
  <?php $this->head() ?>

</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-color="purple" data-image="/modules/admin/web/img/sidebar-5.jpg">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

      <div class="sidebar-wrapper">
            <div class="logo">
                <a href="/" class="simple-text">
                    Bicycle shop
                </a>
            </div>

            <ul class="nav">
                <li>
                    <a href="<?= Url::to('/admin/orders'); ?>">
                        <i class="pe-7s-shopbag"></i>
                        <p>Orders</p>
                    </a>
                </li>
                <li>
                    <a href="<?= Url::to('/admin/products'); ?>">
                        <i class="pe-7s-bicycle"></i>
                        <p>Products</p>
                    </a>
                </li>
                <li>
                    <a href="<?= Url::to('/admin/categories'); ?>">
                        <i class="pe-7s-menu"></i>
                        <p>Products Categories</p>
                    </a>
                </li>
                <li>
                    <a href="<?= Url::to('/admin/detailattribute'); ?>">
                        <i class="pe-7s-edit"></i>
                        <p>Products details</p>
                    </a>
                </li>
                <li>
                    <a href="<?= Url::to('/admin/discounts'); ?>">
                        <i class="pe-7s-piggy"></i>
                        <p>Products Discounts</p>
                    </a>
                </li>
                <li>
                    <a href="<?= Url::to('/admin/users'); ?>">
                        <i class="pe-7s-users"></i>
                        <p>Users</p>
                    </a>
                </li>
                <li>
                    <a href="<?= Url::to('/admin/rent'); ?>">
                        <i class="pe-7s-id"></i>
                        <p>Rent</p>
                    </a>
                </li>
                <li>
                    <a href="<?= Url::to('/admin/reports/orderreports'); ?>">
                        <i class="pe-7s-note2"></i>
                        <p>Report orders</p>
                    </a>
                </li>
                <li>
                    <a href="<?= Url::to('/admin/reports/restreports'); ?>">
                        <i class="pe-7s-note2"></i>
                        <p>Report Rest</p>
                    </a>
                </li>
                <li>
                    <a href="<?= Url::to('/admin/reports/rentsreports'); ?>">
                        <i class="pe-7s-note2"></i>
                        <p>Report Rents</p>
                    </a>
                </li>
            </ul>
      </div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-dashboard"></i>
                <p class="hidden-lg hidden-md">Dashboard</p>
                            </a>
                        </li>
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="fa fa-globe"></i>
                                    <b class="caret hidden-sm hidden-xs"></b>
                                    <span class="notification hidden-sm hidden-xs">5</span>
                  <p class="hidden-lg hidden-md">
                    5 Notifications
                    <b class="caret"></b>
                  </p>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Notification 1</a></li>
                                <li><a href="#">Notification 2</a></li>
                                <li><a href="#">Notification 3</a></li>
                                <li><a href="#">Notification 4</a></li>
                                <li><a href="#">Another notification</a></li>
                              </ul>
                        </li>
                        <li>
                           <a href="">
                                <i class="fa fa-search"></i>
                                <p class="hidden-lg hidden-md">Search</p>
                            </a>
                        </li>
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        <li>
                           <a href="">
                               <p>Account</p>
                            </a>
                        </li>
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <p>
                                      Dropdown
                                      <b class="caret"></b>
                                    </p>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Action</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something</a></li>
                                <li class="divider"></li>
                                <li><a href="#">Separated link</a></li>
                              </ul>
                        </li>
                        <li>
                            <a href="<?= Url::to(['/site/logout']); ?>">
                                <p>Log out</p>
                            </a>
                        </li>
                        <li class="separator hidden-lg hidden-md"></li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="content">
          <div class="container-fluid">
            <?= $content; ?> 
          </div>
        </div>  


        <!--<footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>
                        <li>
                            <a href="#">
                                Home
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                Company
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                Portfolio
                            </a>
                        </li>
                        <li>
                            <a href="#">
                               Blog
                            </a>
                        </li>
                    </ul>
                </nav>
                <p class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script> <a href="http://www.creative-tim.com">Creative Tim</a>, made with love for a better web
                </p>
            </div>
        </footer>-->

    </div>
</div>

<?php $this->endBody() ?>  
  <!-- Datetime picker -->
  <script type="text/javascript">
    $(function(){
      $('#datetimepicker1').datetimepicker({language: 'ru',minuteStepping:10,defaultDate: new Date(),daysOfWeekDisabled:[0,7]});
      $('#datetimepicker2').datetimepicker({language: 'ru',minuteStepping:10,defaultDate: new Date()});
    });
  </script>

</body>
</html>
<?php $this->endPage() ?>